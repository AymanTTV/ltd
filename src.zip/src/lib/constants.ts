
// Secure token for admin setup - in production this should be environment variable
export const ADMIN_SETUP_TOKEN = 'f8392j4028fj20fjw0'; // This is just an example token

export const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
export const MAX_IMAGE_SIZE = 5 * 1024 * 1024; // 5MB