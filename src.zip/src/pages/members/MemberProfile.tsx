// src/pages/members/MemberProfile.tsx
import React, { useEffect, useState } from 'react';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useNavigate, Link } from 'react-router-dom';
import toast from 'react-hot-toast';

interface MemberSession {
  badgeNumber: number | string;
  customerId: string;
  email: string;
  fullName: string;
}

const MemberProfile: React.FC = () => {
  const navigate = useNavigate();
  const sessionStr = localStorage.getItem('memberSession');
  const session = sessionStr
    ? (JSON.parse(sessionStr) as MemberSession)
    : null;

  const [member, setMember] = useState<any>(null);
  const [form, setForm]     = useState({
    fullName: '',
    nickname: '',
    phone: '',
    email: '',
    address: '',
    dob: '',
  });
  const [reason, setReason] = useState('');

  useEffect(() => {
    if (!session) {
      toast.error('Please log in first');
      return navigate('/members/login');
    }
    (async () => {
      try {
        const snap = await getDoc(
          doc(db, 'customers', session.customerId)
        );
        if (!snap.exists()) {
          throw new Error('Profile not found');
        }
        const data = snap.data() as any;
        setMember(data);
        setForm({
          fullName: data.fullName || '',
          nickname: data.nickname || '',
          phone: data.mobile || '',
          email: data.email || '',
          address: data.address || '',
          dob: data.dateOfBirth
            ? data.dateOfBirth.toDate().toISOString().slice(0, 10)
            : '',
        });
      } catch (err) {
        console.error(err);
        toast.error('Error loading profile');
      }
    })();
  }, [session, navigate]);

  const handleChange = (
    field: keyof typeof form,
    value: string
  ) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    if (!reason.trim()) {
      toast.error('Please provide a reason for update');
      return;
    }
    if (!session) return;

    try {
      await updateDoc(
        doc(db, 'customers', session.customerId),
        {
          pendingUpdates: {
            ...form,
            reason,
          },
          pendingApproval: true,
        }
      );
      toast.success('Update request submitted for approval');
      navigate('/members/dashboard');
    } catch (err) {
      console.error(err);
      toast.error('Error submitting update');
    }
  };

  if (!member) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 px-4 py-10">
      <div className="max-w-2xl mx-auto bg-white shadow-md rounded-lg p-6 space-y-6">
        <div className="flex justify-between items-center">
          <Link
            to="/members/dashboard"
            className="text-sm text-primary hover:underline"
          >
            ← Back
          </Link>
          <h2 className="text-xl font-bold">Edit Profile</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input
            type="text"
            placeholder="Full Name"
            value={form.fullName}
            onChange={e =>
              handleChange('fullName', e.target.value)
            }
            className="border px-4 py-2 rounded"
          />
          <input
            type="text"
            placeholder="Nickname"
            value={form.nickname}
            onChange={e =>
              handleChange('nickname', e.target.value)
            }
            className="border px-4 py-2 rounded"
          />
          <input
            type="text"
            placeholder="Phone"
            value={form.phone}
            onChange={e =>
              handleChange('phone', e.target.value)
            }
            className="border px-4 py-2 rounded"
          />
          <input
            type="email"
            placeholder="Email"
            value={form.email}
            onChange={e =>
              handleChange('email', e.target.value)
            }
            className="border px-4 py-2 rounded"
          />
          <input
            type="text"
            placeholder="Address"
            value={form.address}
            onChange={e =>
              handleChange('address', e.target.value)
            }
            className="border px-4 py-2 rounded col-span-full"
          />
          <input
            type="date"
            placeholder="Date of Birth"
            value={form.dob}
            onChange={e => handleChange('dob', e.target.value)}
            className="border px-4 py-2 rounded col-span-full"
          />
        </div>

        <textarea
          placeholder="Reason for update"
          value={reason}
          onChange={e => setReason(e.target.value)}
          className="w-full border px-4 py-2 rounded min-h-[80px]"
        />

        <button
          onClick={handleSubmit}
          className="w-full bg-primary text-white px-4 py-2 rounded hover:bg-primary-600"
        >
          Submit for Approval
        </button>
      </div>
    </div>
  );
};

export default MemberProfile;
